public class LogPassCheck {
    public static boolean checkData(String inputLog, String inputPassword){
        if (inputLog.length() < 6 || inputPassword.length() < 6) {
            return true;
        }
        else {
            return false;
        }
    }
}
