import java.io.FileReader;
import java.io.IOException;

public class Checker {
    public static String getUsersLogin(){
        String login = "";
        try(FileReader reader = new FileReader("database.txt"))
        {
            int c;
            while((c=reader.read())!=-1){

                login += (char)c;
            }
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
        return login;
    }

}
