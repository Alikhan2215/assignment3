import java.io.FileNotFoundException;
import java.util.Scanner;


public class Test {
    public static void main(String[] args) throws FileNotFoundException {
        CodeGenerate vCode = new CodeGenerate();
        String verCode = vCode.generateCode();
        System.out.println(verCode);
        System.out.println(verCode);
        System.out.println();

        Userdata data = new Userdata();
        Scanner reset = new Scanner(System.in);
        System.out.println("enter code");
        String code = reset.nextLine();

        if (code.equals(verCode)){

            System.out.println("Enter new password");
            data.setRealPassword(reset.nextLine());
            System.out.println("Password has been successfully changed!");
        }
        else if(code != verCode){
            System.out.println(code);
            System.out.println(verCode);
            System.out.println("Verification code fail. Stop trying to hack this user!");
        }
    }
}
