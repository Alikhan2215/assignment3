import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Scanner;
public class Main
{

    public static void main(String[] args) throws MessagingException, IOException {
        Scanner userdata = new Scanner(System.in);
        Userdata data = new Userdata();
        PassCheck correctPass = new PassCheck();
        LogPassCheck correctData = new LogPassCheck();

        String realLog = data.getUserLogin();
        String realPassword = EmailSender.getUsersPass();
        String realIIN = data.getRealIIN();
        int attempts = 3;

        while (attempts != 0) {
            System.out.println("Do you want to log in with your IIN or email?");
            System.out.print("Type IIN or Email: ");
            Scanner sc = new Scanner(System.in);
            String answer = sc.nextLine();

            if (answer.equals("IIN")) {
                System.out.print("Enter your IIN: ");
                data.setInputIIN(sc.nextLine());

                System.out.print("Enter your password: ");
                data.setInputPassword(userdata.nextLine());

                String inputIIN = data.getInputIIN();
                String inputPassword = data.getInputPassword();

                if (inputIIN.equals(realIIN) && inputPassword.equals(realPassword)) {
                    System.out.println("YOU HAVE ENTERED");
                    return;
                }

                else {
                    attempts = attempts - 1;
                    System.out.println("IIN or password is incorrect");

                    if (attempts != 1) {
                        System.out.println(attempts + " attempts left");
                        System.out.println();
                    } else {
                        System.out.println(attempts + " attempt left");
                        System.out.println();
                    }
                }

            }
            else if (answer.equals("Email")){

                System.out.print("Enter your login: ");
                data.setInputString(userdata.nextLine()); //set login to whatever we input

                System.out.print("Enter your password: ");
                data.setInputPassword(userdata.nextLine()); //set password to whatever we input

                String inputLog = data.getInputString();
                String inputPassword = data.getInputPassword();

                if (correctData.checkData(inputLog, inputPassword)) {
                    System.out.println("The minimum length of the login and password is 6 characters");
                    System.out.println();
                    continue;
                }
                if (!correctPass.checkString(inputPassword)) {
                    System.out.println("Password should contain at least 1 capital, 1 lower case letter and a number");
                    System.out.println();
                    continue;
                }

                if (inputLog.equals(realLog) && inputPassword.equals(realPassword)) {
                    System.out.print("You have entered!");
                    return;
                } else {
                    attempts = attempts - 1;
                    System.out.println("Login or password is incorrect");

                    if (attempts != 1) {
                        System.out.println(attempts + " attempts left");
                        System.out.println();
                    } else {
                        System.out.println(attempts + " attempt left");
                        System.out.println();
                    }
                }
            }
        }
        if(attempts == 0){
            System.out.println("Reset password? Y or N");

            Scanner reset = new Scanner(System.in);
            String answer = reset.nextLine();

            if (answer.equals("Y")){
                data.codeWriter();
                EmailSender.main(null);
                System.out.println("We sent code on your email, please enter it: ");
                String code = reset.nextLine();



                if (code.equals(EmailSender.getRecoveryCode())){
                    System.out.println("Enter new password");
                    data.setRealPassword(reset.nextLine());
                    data.passWriter();
                    System.out.println("Password has been successfully changed!");
                }
                else {
                    System.out.println("Verification code fail. Stop trying to hack this user!");
                }
            }
            else if (answer.equals("N")){
                System.out.println("End");
            }


        }
    }
}
