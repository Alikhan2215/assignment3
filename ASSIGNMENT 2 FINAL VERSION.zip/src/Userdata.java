import java.io.*;
import java.util.Scanner;

public class Userdata {

    private String realPassword;
    public String getRealPassword(){
        return realPassword;
    }
    public void setRealPassword(String newRealPassword){
        this.realPassword = newRealPassword;
    }

    private String inputString;
    public String getInputString(){ //Getter
      return inputString;
    }
    public void setInputString(String newLogin){ //Setter
      this.inputString = newLogin;
    }

    private String inputPassword;
    public String getInputPassword(){
      return inputPassword;
    }
    public void setInputPassword(String newPassword){
        this.inputPassword = newPassword;
    }

    public String getVerCode(){
        CodeGenerate vCode = new CodeGenerate();
        return vCode.generateCode();
    }

    private String userLogin = "doshchanov_alikhan@mail.ru";
    public String getUserLogin(){
        return userLogin;
    }

    private String inputIIN;
    public String getInputIIN(){
        return inputIIN;
    }
    public void setInputIIN(String newInputIIN){
        this.inputIIN = newInputIIN;
    }
    private String realIIN = "040626550535";
    public String getRealIIN(){
        return realIIN;
    }
    public void setRealIIN(String newRealIIN){
        this.realIIN = newRealIIN;
    }

    public void codeWriter(){

        try(FileWriter writer = new FileWriter("passwordToken.txt", false))
        {
            writer.write(this.getVerCode());
            writer.flush();
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }

    }

    public void passWriter(){

        try(FileWriter writer = new FileWriter("pass.txt", false))
        {
            writer.write(this.getRealPassword());
            writer.flush();
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }

    }


}


